

$(document).ready(function(){
    $('#bar1').barfiller();
});
$(document).ready(function(){
    $('#bar2').barfiller();
});
$(document).ready(function(){
    $('#bar3').barfiller();
});


$(function(){
$('.circlechart').circlechart();
});
$(document).ready(function(){

	$('#bar1').barfiller({ barColor: '#ff451b', duration: 3000 });
	$('#bar2').barfiller({ barColor: '#ff451b', duration: 3000 });
	$('#bar3').barfiller({ barColor: '#ff451b', duration: 3000 });
	
});


$('.slider').slick({
    dots: false,
    infinite: true,
    arrows: false,
    speed: 300,
    slidesToShow: 1,
    slidesToScroll: 1,
    fade: true,
   
  });